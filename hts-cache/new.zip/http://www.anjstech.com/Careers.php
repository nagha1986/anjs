<head>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<title>Corporate Overview</title>
<meta name="description" content="ANJS Tech is a leading Global Consulting and IT service firm, offering consulting services for H1B transfer, vmware and IT Staffing" />
<meta name="keywords" content="IT Staffing,  staff augmentation, staff Augmentation Services, infrastructure management, it consulting services in all over USA, business intelligence, data warehousing, Software, java,  IT Staffing in all over USA" />
<link href="css/tab_style_inner.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="css/fancybox.css" />
<script type="text/javascript" src="nav/js/jquery-1.7.2.min.js"></script>
<!--<link rel="stylesheet" type="text/css" href="nav/styles.css" media="all" />
<link rel="stylesheet" type="text/css" href="nav/fdw-demo.css" media="all" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:700' rel='stylesheet' type='text/css' />-->
<script type="text/javascript" src="scripts/validate.js"></script>

<script type="text/javascript">
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','../www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-39768382-1', 'ANJS Tech.com');
  ga('send', 'pageview');

</script>

<link href="css/style.css" rel="stylesheet" type="text/css" />

</head>

<body bgcolor="#ffffff">
<table width="100%" cellpadding="0" cellspacing="0">
	<tr>
		<td>
			<table class="tablewidth" cellpadding="0" cellspacing="0" align="center">
				<tr>
					<td><div class="header">
	<div class="logo"><a href="index.php" style="border:0px;"><img src="images/logo.png" class="logoimg" alt="ANJS Tech" title="ANJS Tech" border="0"/></a></div>
	<div class="headmidtext hideANDseek">
		<div class="followus">Follow us on</div>
			<div class="sm">
				<ul class="social" id="css3">
					<li class="linkedin">
						<a href="#" target="_blank"><strong class="maintext">LinkedIn</strong></a>						</li>
					<li class="twitter">
						<a href="#" target="_blank"><strong class="maintext">Twitter</strong></a>						</li>
					<li class="facebook">
						<a href="#" target="_blank"><strong class="maintext">Facebook</strong></a>						</li>
																	
				</ul>
			</div>
		</div>
	</div>
	<div class="headrightbox">
		<div class="sendusbox"><img src="images/send-email-icon.gif" alt="Send Email" title="Send Email" /></div> &nbsp;&nbsp;&nbsp;<div style="float:right;"><a href="mailto:info@anjstech.com" style="text-decoration:none"><font class="heademailtext">Send us email now</font></a></div>
		<div style="clear:both"></div>
		<div class="phbox"><img src="images/phone_icon.jpg" alt="Phone" title="Phone" /></div> <div class="headphtext" style="float:right;">+1 (732)-603-0069</div>
	</div>	
	<div style="clear:right"></div>	
	<div class="navibox"><link rel="stylesheet" type="text/css" href="nav/styles.css" media="all" />
<link rel="stylesheet" type="text/css" href="nav/fdw-demo.css" media="all" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:700' rel='stylesheet' type='text/css' />
<!--<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.2/jquery.min.js"></script>-->
<script type="text/javascript">  
<!--  // building select nav for mobile width only -->
$(function(){
	// building select menu
	$('<select />').appendTo('nav');

	// building an option for select menu
	$('<option />', {
		'selected': 'selected',
		'value' : '',
		'text': 'Choise Page...'
	}).appendTo('nav select');

	$('nav ul li a').each(function(){
		var target = $(this);

		$('<option />', {
			'value' : target.attr('href'),
			'text': target.text()
		}).appendTo('nav select');

	});

	// on clicking on link
	$('nav select').on('change',function(){
		window.location = $(this).find('option:selected').val();
	});
});

// show and hide sub menu
$(function(){
	$('nav ul li').hover(
		function () {
			//show its submenu
			$('ul', this).slideDown(150);
		}, 
		function () {
			//hide its submenu
			$('ul', this).slideUp(150);			
		}
	);
});
//end
</script>


<table border="0">
	<td>
			<div id="container">
				<header>
					<div id="fdw">
							<!--nav-->
								<nav>
									<ul>
										<li class='current'><a href="index.php">Home</a></li>
											<li ><a href="CorporateOverview.php">Who We Are<span class="arrow"></span></a>
											
										</li>							
										<li ><a href="Services.php">Services<span class="arrow"></span></a>
											<ul style="display: none;" class="sub_menu1">
												<li class="arrow_top"></li>
												<li><a  href="StaffAugmentation.php">Staffing</a></li>
												<li><a  href="SoftwareDevelopment.php">Software Development</a></li>
												<li><a  href="InfrastructureManagement.php">Infrastructure Management</a></li>
												<li><a  href="ITConsulting.php">IT Consulting</a></li>
												<li><a  href="CorporateTrainings.php">Trainings</a></li>
												</ul>
										</li>
										
																			
										<li ><a href="Careers.php">Careers<span class="arrow"></span></a>
											
										</li>										
										<li ><a href="ContactUs.php">Contact Us</a></li>
									</ul>
								</nav>
					</div><!-- end fdw -->
				</header><!-- end header -->
			</div>
		</td>
</table></div>	<div style="clear:both"></div>	
</div></td>
				</tr>
				<tr><td height="2px" colspan="3"></td></tr>
			</table>
		</td>
	</tr>
	<tr class="innerbgimg">
		<td align="center"><img src="images/banner-careers1.png" style="width:100%; height:auto; max-width:1000px" alt="ANJS TEch Banner" /></td>
	</tr>
	<tr>
		<td>
			<table class="tablewidth" cellpadding="0" cellspacing="0" align="center">
				<tr><td height="20px" colspan="3"></td></tr>
				<tr>
					<td colspan="3">
						<table width="100%" cellpadding="0" cellspacing="0">
							<tr>
								<td class="innertable" valign="top">
									<table cellpadding="0" cellspacing="0" width="100%" class="dashline">
										<tr>
											<td width="60%" class="inner_heading">Careers</td>
											<td width="40%" class="inner_heading_nav hideANDseek">Home > Careers</td>
										</tr>
										<tr><td height="15px"></td></tr>
										<tr>
											<td colspan="2" align="right">
												<table class="innertablein" cellpadding="0" cellspacing="0">
													<tr class="inner_text">
														<td style="padding-right:10px; color:#797979; font-size:14px; margin:5px 0 15px;">We are always interested in hearing from qualified applicants and always take the time to read and consider applications. Send your resume or CV to <a class="page" href="mailto:info@anjstech.com">info@anjstech.com</a> and we will be in touch. Your application should include why you wish to work at ANJS TEch,inc,  along with relevant documents of any degree or qualification you possess.</td>
													
													</tr>
													<tr><td height="15px"></td></tr>
													<tr><td class="inner_subheading">Better IT Jobs</td></tr>
													<tr><td height="1px" bgcolor="#CCCCCC"></td></tr>
													<tr><td height="10px"></td></tr>
													<tr>
													
													<td style="padding-right:10px; color:#797979; font-size:14px; margin:5px 0 15px;">Our IT professionals are our greatest asset. We are committed to your long-term success, and we are here to help you reach your IT career goals. We work with 
high-tech employers.We’ll help you find the right IT career opportunities to achieve your goals.
													</td>
													</tr>	
										<tr><td height="15px"></td></tr>
													<tr><td class="inner_subheading">IT Career Advice</td></tr>
													<tr><td height="1px" bgcolor="#CCCCCC"></td></tr>
													<tr><td height="10px"></td></tr>
													
													<td style="padding-right:10px; color:#797979; font-size:14px; margin:5px 0 15px;">We don't just fill IT job openings; we help you reach your career goals. Share your short and long-term IT career goals with us, and we’ll decide a structured plan to help you achieve them.
													</td>
													</tr>
										<tr><td height="15px"></td></tr>
													<tr><td class="inner_subheading">Open Positions</td></tr>
													<tr><td height="1px" bgcolor="#CCCCCC"></td></tr>
													<tr><td height="10px"></td></tr>
													<tr>
													
													<td style="padding-right:10px; color:#797979; font-size:14px; margin:5px 0 15px;">We give you access to the best IT jobs at the best companies. View our current openings and take the next step in your career.
													</td>
													</tr>
										<tr><td height="15px"></td></tr>
										
										
													<tr><td height="15px"></td></tr>										
												</table>								
											</td>
										</tr>
									</table>					
								</td>
								<td width="12px"></td>
								<td width="tablerightside" valign="top" class="hideANDseek">
									<div class="orangeBox">
  <div class="orangeBoxTop"></div>
  <div class="orangeBoxMiddle">
	<h2>Careers</h2>
	<h3 style="color:#fff">When you partner with us in your job search, you may notice a refreshing difference in the personal approach that we take to help you navigate the job search process. Why? We truly care about helping you advance your career.</h3>
	<!--<ul>
	  <li><a href="JobOpportunities.html">Job Opportunities</a> </li>
	  <li><a href="WorkCulture.html">Work Culture</a> </li>
	  <li><a href="ApplyOnline.html">Apply Online</a> </li>
	 
	   <li><a href="ReferralPrograms.html">Referral Programs</a> </li>
	  <li class="last"><a href="WhatANJS TEchoffers.html">What ANJS TEch Offers </a> </li>
	  <!--<li><a href="careers/post-your-resume.aspx">Post your Resume</a> </li>
	</ul>-->
  </div>
  <div class="orangeBoxBottom"></div>
</div>
<table cellpadding="0" cellspacing="0" width="100%">
						
							<tr><td height="10px"></td></tr>
															<tr><td height="10px"></td></tr>
														
							<tr><td height="30px"></td></tr>
							<tr>
								<td height="50px" bgcolor="#D3D3D3" align="center" style="padding-left:15px">
									<table cellpadding="0" cellspacing="0" border="0">
										<tr>
											<td valign="middle" width="100px" style="font-family:Calibri; color:#666666; font-size:19px; padding:0 14px 0 0;">Follow us on</td>
											<!--<td style="padding:0 7px 0 7px;"><a href="http://www.linkedin.com/company/ANJS Tech-inc" target="_blank"><img src="images/LinkedIn.jpg" alt="LinkedIn" title="LinkedIn" border="0" /></a></td>
											<td style="padding:0 7px 0 7px;"><a href="https://twitter.com/ANJS Tech_Inc" target="_blank"><img src="images/twitter.jpg" alt="Twitter" title="Twitter" border="0" /></a></td>
											<td style="padding:0 7px 0 7px;"><a href="http://www.facebook.com/pages/ANJS Tech/181936941831462" target="_blank"><img src="images/facebook.jpg" alt="Facebook" title="Facebook" border="0" /></a></td>
											<td style="padding:0 0 0 7px;"><a href="http://www.flickr.com/people/57847475@N05/" target="_blank"><img src="images/Flickr.jpg" alt="Flickr" title="Flickr" border="0" /></a></td>-->
											<td align="right">
												<ul class="social" id="css3">
													<li class="linkedin">
														<a href="#" target="_blank"><strong class="maintext">LinkedIn</strong></a>
													</li>
													<li class="twitter">
														<a href="#" target="_blank"><strong class="maintext">Twitter</strong></a>
													</li>
													<li class="facebook">
														<a href="#" target="_blank"><strong class="maintext">Facebook</strong></a>
													</li>
													<li class="flickr">
														<a href="#" target="_blank"><strong class="maintext">Flickr</strong></a>
													</li>													
												</ul>
											</td>
										</tr>
									</table>								
								</td>
							</tr>
							<tr><td height="10px"></td></tr>
						</table>							</td>
							</tr>
						</table>		
					</td>
				</tr>
				<!--<tr><td colspan="3" height="25px"></td></tr>-->
				<!--<tr><td colspan="3" class="hline"></td></tr>
				<tr><td colspan="3" height="5px"></td></tr>
				<tr>
					<td colspan="3"></td>
				</tr>-->
			</table>
		</td>
	</tr>
</table>
<div class="footernew">
	<table class="tablewidth" cellpadding="0" cellspacing="0" align="center">
		<tr>
			<td colspan="3">
			
					<div style="text-align:center;padding-top:10px" class="footer copyright">2016 @ ANJS Tech. All Rights Reserved</div>
				
			</td>
		</tr>
	</table>	
</div>
<!-- begin olark code -->
</body>

<!-- Mirrored from www.ANJS TEch.com/Careers.php by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 16 Mar 2016 05:40:54 GMT -->
</html>