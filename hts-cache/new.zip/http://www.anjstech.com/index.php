
<head>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<title>IT Consulting and Services Company</title>
<meta name="description" content="ANJS TEch is a leading Global Consulting and IT service firm, offering consulting services for H1B transfer, and IT Staffing" />
<meta name="keywords" content="IT Staffing,  staff augmentation, staff Augmentation Services, infrastructure management, it consulting services in all over USA, business intelligence, data warehousing, Software, java,  IT Staffing in all over USA" />
<link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon" />
<link href="css/tab_styleH.css" rel="stylesheet" type="text/css" />
<link href="css/tab_style.css" rel="stylesheet" type="text/css" />

<script type="text/javascript" src="js/jquery.js"></script>

<script type='text/javascript' src="nav/js/jquery-1.7.2.min.js"></script>
<script src="../ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js"></script>
<script src="js/jquery.bxslider.min.js"></script>
<link href="js/jquery.bxslider.css" rel="stylesheet" />

<script type="text/javascript">
  $(document).ready(function(){
    
	$('.bxslider').bxSlider({
	  auto: true,
	  autoHover: true,
	  pager: false,
	  mode: 'fade',
	  speed: 1500
	  /*autoControls: true*/
	});
  });
</script>

<link href="css/style.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="scripts/ticker.js"></script>

<script type="text/javascript">
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','../www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-39768382-1', 'ANJS TEch.com');
  ga('send', 'pageview');

</script>


<style type="text/css" media="screen">
	#cycler{position:relative;}
	#cycler img{position:absolute;z-index:1;background-color:white}
	#cycler img.active{z-index:3}
	
	
</style>  
</head>
<body onLoad="fillup();">
<div class="backgroundimgblue">
<table class="tablewidth" cellpadding="0" cellspacing="0" align="center">
	<tr>
		<td><div class="header">
	<div class="logo"><a href="index.php" style="border:0px;"><img src="images/logo.png" class="logoimg" alt="ANJS Tech" title="ANJS TEch" border="0"/></a></div>
	<div class="headmidtext hideANDseek">
		<div class="followus">Follow us on</div>
			<div class="sm">
				<ul class="social" id="css3">
					<li class="linkedin">
						<a href="#" target="_blank"><strong class="maintext">LinkedIn</strong></a>						</li>
					<li class="twitter">
						<a href="#" target="_blank"><strong class="maintext">Twitter</strong></a>						</li>
					<li class="facebook">
						<a href="#" target="_blank"><strong class="maintext">Facebook</strong></a>						</li>
																	
				</ul>
			</div>
		</div>
	</div>
	<div class="headrightbox">
		<div class="sendusbox"><img src="images/send-email-icon.gif" alt="Send Email" title="Send Email" /></div> &nbsp;&nbsp;&nbsp;<div style="float:right;"><a href="mailto:info@datassol.com" style="text-decoration:none"><font class="heademailtext">Send us email now</font></a></div>
		<div style="clear:both"></div>
		<div class="phbox"><img src="images/phone_icon.jpg" alt="Phone" title="Phone" /></div> <div class="headphtext" style="float:right;">+1 (111) 222-3330</div>
	</div>	
	<div style="clear:right"></div>	
	<div class="navibox"><link rel="stylesheet" type="text/css" href="nav/styles.css" media="all" />
<link rel="stylesheet" type="text/css" href="nav/fdw-demo.css" media="all" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:700' rel='stylesheet' type='text/css' />
<!--<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.2/jquery.min.js"></script>-->
<script type="text/javascript">  
<!--  // building select nav for mobile width only -->
$(function(){
	// building select menu
	$('<select />').appendTo('nav');

	// building an option for select menu
	$('<option />', {
		'selected': 'selected',
		'value' : '',
		'text': 'Choise Page...'
	}).appendTo('nav select');

	$('nav ul li a').each(function(){
		var target = $(this);

		$('<option />', {
			'value' : target.attr('href'),
			'text': target.text()
		}).appendTo('nav select');

	});

	// on clicking on link
	$('nav select').on('change',function(){
		window.location = $(this).find('option:selected').val();
	});
});

// show and hide sub menu
$(function(){
	$('nav ul li').hover(
		function () {
			//show its submenu
			$('ul', this).slideDown(150);
		}, 
		function () {
			//hide its submenu
			$('ul', this).slideUp(150);			
		}
	);
});
//end
</script>


<table border="0">
	<tr>
		<td>
			<div id="container">
				<header>
					<div id="fdw">
							<!--nav-->
								<nav>
									<ul>
										<li class='current'><a href="Index.php">Home</a></li>
											<li ><a href="CorporateOverview.php">Who We Are<span class="arrow"></span></a>
											
										</li>							
										<li ><a href="Services.php">Services<span class="arrow"></span></a>
											<ul style="display: none;" class="sub_menu1">
												<li class="arrow_top"></li>
												<li><a  href="StaffAugmentation.php">Staffing</a></li>
												<li><a  href="SoftwareDevelopment.php">Software Development</a></li>
												<li><a  href="InfrastructureManagement.php">Infrastructure Management</a></li>
												<li><a  href="ITConsulting.php">IT Consulting</a></li>
												<li><a  href="CorporateTrainings.php">Trainings</a></li>
												</ul>
										</li>
										
																			
										<li ><a href="Careers.php">Careers<span class="arrow"></span></a>
											</li>										
										<li ><a href="ContactUs.php">Contact Us</a></li>
									</ul>
								</nav>
					</div><!-- end fdw -->
				</header><!-- end header -->
			</div>
		</td>
	</tr>
</table></div>
	<div style="clear:both"></div>	
</div></td>
	</tr>
	<tr><td height="2px" colspan="3"></td></tr>
	
	<tr>
		<td colspan="3"><!--<section>     
	<div style="overflow:hidden;"> 
			<div class="pix_diapo">

				<div>
					<img src="images/banner/Banner01.jpg" alt="ANJS Tech Banner" title="ANJS Tech Banner" style="max-width:100%;height:auto;" />
				</div>
				
				<div>
					<img src="images/banner/Banner02.jpg" alt="ANJS Tech Banner" title="ANJS Tech Banner" style="max-width:100%;height:auto;" />                    
				</div>
				
				<div>
					<img src="images/banner/Banner03.jpg" alt="ANJS Tech Banner" title="ANJS Tech Banner" style="max-width:100%;height:auto;" />                    
				</div>
									
				<div>
					<img src="images/banner/Banner04.jpg" alt="ANJS Tech Banner" title="ANJS Tech Banner" style="max-width:100%;height:auto;" />                    
				</div>
		   </div>                
	</div>    
</section>-->
<ul class="bxslider">
  <li><img src="images/banner/Banner07.jpg" alt="ANJS Tech Banner" title="ANJS Tech Banner" /></li>
  <li><img src="images/banner/Banner02.jpg" alt="ANJS Tech Banner" title="ANJS Tech Banner" /></li>
  <li><img src="images/banner/Banner03.jpg" alt="ANJS Tech Banner" title="ANJS Tech Banner" /></li>
  <li><img src="images/banner/Banner04.jpg" alt="ANJS Tech Banner" title="ANJS Tech Banner" /></li>
</ul>

<!--<ul class="bxslider">
  <li><a href="AboutUs.php"><img src="images/bannernew/banner.jpg" alt="ANJS Tech Banner" title="ANJS Tech Inc" border="0" /></a></li>
  <li><a href="WorkSpaceManagement.php"><img src="images/bannernew/banner2.jpg" alt="ANJS Tech Banner" title="Workspace Solution" border="0" /></a></li>
  <li><a href="Mobile.php"><img src="images/bannernew/banner3.jpg" alt="ANJS Tech Banner" title="Mobile Application Development" border="0" /></a></li>
  <li><a href="StaffAugmentation.php"><img src="images/bannernew/banner4.jpg" alt="ANJS Tech Banner" title="IT Consulting & Staffing" border="0" /></a></li>
  <li><a href="InfrastructureManagement.php"><img src="images/bannernew/banner5.jpg" alt="ANJS Tech Banner" title="IT Infrastructure Management" border="0" /></a></li>
  <li><a href="SoftwareDevelopment.php"><img src="images/bannernew/banner6.jpg" alt="ANJS Tech Banner" title="Software Development" border="0" /></a></li>
</ul>
--></td>
	</tr>	
	
	<!--<tr><td height="8px" colspan="3"></td></tr>
	<!--<tr>
		<td>
			<table width="100%" cellpadding="0" cellspacing="0" border="0">
				<tr><td><h3 class="fontorange">Partnerships</h3></td><td><h3 class="fontorange">Clients</h3></td></tr>				
				<tr>
					<td>
						<table cellpadding="0" cellspacing="0" border="0">
							<tr>
								<td rowspan="3"><img class="partnerslogo" src="images/microsoft%20gold%20partner%20logo.png"></td>
								<td width="5px">&nbsp;</td>
								<td align="center"><img class="partnerslogo" src="images/E-Verify.jpg"></td>
								<td width="5px">&nbsp;</td>
								<td rowspan="3"><img class="partnerslogo" src="images/VMW_PARTNER_SOLUTION_PROVIDER_PRO.png"></td>
								<td width="5px">&nbsp;</td>
								<td rowspan="3"><img class="partnerslogo" src="images/Solution-Provider_Blue.png"></td>
								<td width="5px">&nbsp;</td>
								<td><img class="partnerslogo" src="images/checkpoint.png"></td>
								<td width="5px">&nbsp;</td>
								<td><img class="partnerslogo" src="images/aspire.png"></td>
							</tr>
							<tr><td height="1px"></td></tr>
							<!--<tr>
								<td></td>								
								<td><img class="partnerslogo" src="images/checkpoint.png"></td>
								<td></td>
							</tr>-->
															
					<!--	</table>-->
						  
					<!--</td>
					<td class="hideANDseek" width="30%">
						<script type="text/javascript">
							//Specify the slider's width (in pixels)							
							var sliderwidth="356px"
							//Specify the slider's height
							var sliderheight="52px"
							//Specify the slider's slide speed (larger is faster 1-10)
							var slidespeed=2
							//configure background color:
							slidebgcolor="#FFFFFF"
		
							//Specify the slider's images
							var leftrightslide=new Array()
							var finalslide=''
							leftrightslide[0]='<img src="images/clientlogos/AIG_logo.jpg" border="0" class="resize" alt="AIG" />'
							leftrightslide[1]='<img src="images/clientlogos/Bank_of_America.jpg" border="0" class="resize" alt="Bank of America" />'					
							leftrightslide[2]='<img src="images/clientlogos/Barclays_logo.jpg" border="0" class="resize" alt="Barclays" />'
							leftrightslide[3]='<img src="images/clientlogos/CEB-logo.jpg" border="0" class="resize" alt="CEB" />'
							leftrightslide[4]='<img src="images/clientlogos/Cisco_logo.jpg" border="0" class="resize" alt="Cisco" />'
							leftrightslide[5]='<img src="images/clientlogos/CIT_Group_logo.jpg" border="0" class="resize" alt="CIT Group" />'
							leftrightslide[6]='<img src="images/clientlogos/Credit_Suisse.jpg" border="0" class="resize" alt="Credit Suisse" />'
							leftrightslide[7]='<img src="images/clientlogos/EDS_logo.jpg" border="0" class="resize" alt="EDS" />'
							leftrightslide[8]='<img src="images/clientlogos/Freddie_Mac.jpg" border="0" class="resize" alt="Freddie Mac" />'
							leftrightslide[9]='<img src="images/clientlogos/Goodyear_logo.jpg" border="0" class="resize" alt="Goodyear" />'
							leftrightslide[10]='<img src="images/clientlogos/header-bcbsa-logo.jpg" border="0" class="resize" alt="BCBSA" />'
							leftrightslide[11]='<img src="images/clientlogos/J_P_Morgan_Chase_Logo.jpg" border="0" class="resize" alt="J P Morgan Chase" />'
							leftrightslide[12]='<img src="images/clientlogos/Lehman_Brothers.jpg" border="0" class="resize" alt="Lehman Brothers" />'
							leftrightslide[13]='<img src="images/clientlogos/Logo_fid.jpg" border="0" class="resize" alt="FID" />'
							leftrightslide[14]='<img src="images/clientlogos/McKinsey_and_Company_Logo.jpg" border="0" class="resize" alt="McKinsey and Company" />'
							leftrightslide[15]='<img src="images/clientlogos/Mercedes-Benz_logo.jpg" border="0" class="resize" alt="Mercedes Benz" />'
							leftrightslide[16]='<img src="images/clientlogos/Merrill_logo.jpg" border="0" class="resize" alt="Merrill" />'
							leftrightslide[17]='<img src="images/clientlogos/MetLife_Logo.jpg" border="0" class="resize" alt="MetLife" />'
							leftrightslide[18]='<img src="images/clientlogos/Microsoft_logo.jpg" border="0" class="resize" alt="Microsoft" />'
							leftrightslide[19]='<img src="images/clientlogos/Prudential_Financial.jpg" border="0" class="resize" alt="Prudential Financial" />'
							leftrightslide[20]='<img src="images/clientlogos/Scholastic_logo.jpg" border="0" class="resize" alt="Scholastic" />'
							leftrightslide[21]='<img src="images/clientlogos/State_Street_Boston_logo.jpg" border="0" class="resize" alt="Yellow & Green Peas" />'
							leftrightslide[22]='<img src="images/clientlogos/teamsters-logo.jpg" border="0" class="resize" alt="Teamsters" />'
							leftrightslide[23]='<img src="images/clientlogos/U.S._Bancorp_logo.jpg" border="0" class="resize" alt="U.S. Bancorp" />'
							leftrightslide[24]='<img src="images/clientlogos/UBS_Logo.jpg" border="0" class="resize" alt="UBS" />&nbsp;&nbsp;&nbsp;&nbsp;'
		
							//Specify gap between each image (use HTML):
							var imagegap="&nbsp;&nbsp;&nbsp;&nbsp;"
		
							//Specify pixels gap between each slideshow rotation (use integer):
							var slideshowgap=0
		
							////NO NEED TO EDIT BELOW THIS LINE////////////
		
							var copyspeed=slidespeed
							leftrightslide='<nobr>'+leftrightslide.join(imagegap)+'</nobr>'
							var iedom=document.all||document.getElementById
							if (iedom)
							document.write('<span id="temp" style="visibility:hidden;position:absolute;top:-100px;left:-9000px">'+leftrightslide+'</span>')
							var actualwidth=''
							var cross_slide, ns_slide
		
							function fillup(){
							if (iedom){
							cross_slide=document.getElementById? document.getElementById("test2") : document.all.test2
							cross_slide2=document.getElementById? document.getElementById("test3") : document.all.test3
							cross_slide.innerHTML=cross_slide2.innerHTML=leftrightslide
							actualwidth=document.all? cross_slide.offsetWidth : document.getElementById("temp").offsetWidth
							cross_slide2.style.left=actualwidth+slideshowgap+"px"
							}
							else if (document.layers){
							ns_slide=document.ns_slidemenu.document.ns_slidemenu2
							ns_slide2=document.ns_slidemenu.document.ns_slidemenu3
							ns_slide.document.write(leftrightslide)
							ns_slide.document.close()
							actualwidth=ns_slide.document.width
							ns_slide2.left=actualwidth+slideshowgap
							ns_slide2.document.write(leftrightslide)
							ns_slide2.document.close()
							}
							lefttime=setInterval("slideleft()",30)
							}
							//window.onload=fillup
		
							function slideleft(){
							if (iedom){
							if (parseInt(cross_slide.style.left)>(actualwidth*(-1)+8))
							cross_slide.style.left=parseInt(cross_slide.style.left)-copyspeed+"px"
							else
							cross_slide.style.left=parseInt(cross_slide2.style.left)+actualwidth+slideshowgap+"px"
		
							if (parseInt(cross_slide2.style.left)>(actualwidth*(-1)+8))
							cross_slide2.style.left=parseInt(cross_slide2.style.left)-copyspeed+"px"
							else
							cross_slide2.style.left=parseInt(cross_slide.style.left)+actualwidth+slideshowgap+"px"
		
							}
							else if (document.layers){
							if (ns_slide.left>(actualwidth*(-1)+8))
							ns_slide.left-=copyspeed
							else
							ns_slide.left=ns_slide2.left+actualwidth+slideshowgap
		
							if (ns_slide2.left>(actualwidth*(-1)+8))
							ns_slide2.left-=copyspeed
							else
							ns_slide2.left=ns_slide.left+actualwidth+slideshowgap
							}
							}
		
							if (iedom||document.layers){
							with (document){
							document.write('<table border="0" cellspacing="0" cellpadding="0"><td valign="center">')
							if (iedom){
							write('<div style="position:relative;width:'+sliderwidth+';height:'+sliderheight+';overflow:hidden">')
							write('<div style="position:absolute;width:'+sliderwidth+';height:'+sliderheight+';background-color:'+slidebgcolor+'" onMouseover="copyspeed=0" onMouseout="copyspeed=slidespeed">')
							write('<div id="test2" style="position:absolute;left:0px;top:0px"></div>')
							write('<div id="test3" style="position:absolute;left:-1000px;top:0px"></div>')
							write('</div></div>')
							}
							else if (document.layers){
							write('<ilayer width='+sliderwidth+' height='+sliderheight+' name="ns_slidemenu" bgColor='+slidebgcolor+'>')
							write('<layer name="ns_slidemenu2" left=0 top=0 onMouseover="copyspeed=0" onMouseout="copyspeed=slidespeed"></layer>')
							write('<layer name="ns_slidemenu3" left=0 top=0 onMouseover="copyspeed=0" onMouseout="copyspeed=slidespeed"></layer>')
							write('</ilayer>')
							}
							document.write('</td></table>')
							}
							}
						</script>
							
					</td>
				</tr>
			</table>
		</td>
	</tr>-->
	<tr><td height="10px" colspan="3"></td></tr>
	<tr><td class="hline" colspan="3"><!--<img src="images/shadowseparator.jpg">--></td></tr>
	<tr><td height="10px" colspan="3"></td></tr>
	
	<tr>
	  <td colspan="3" align="center">
			<table cellpadding="0" cellspacing="0" width="99.7%">
				<tr><td height="10px;" align="center"></td></tr>
				<tr>
					<td class="inner_textw" style="padding-left:0.6%">
						<div class="boxNavigationsH">
							<ul class="servicesLanding">
							  <li><a href="SoftwareDevelopment.php" class="positionsStaffAugm">Web/Mobile Application Development</a></li>
							  <li><a href="StaffAugmentation.php" class="positionsWrkSpacMgmt">Staffing</a></li>
							  <li class="last"><a href="Services.php" class="positionsITCons"> Services</a></li>
							  <li class="text">ANJS Tech provides expert developers for your web & mobile application development requirement. <a href="SoftwareDevelopment.php" class="hrf">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></li>
							  <li class="text">ANJS Tech specializes in outsourcing of manpower on a skill requirement or per project basis. <a href="StaffAugmentation.php" class="hrf">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></li>
							  <li class="text last">ANJS Tech has expertise in providing high quality engineering design, drafting and 3D modelling services <a href="Services.php" class="hrf">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></li>
							  <li><a href="InfrastructureManagement.php" class="positionsSoftDev">Infrastructure Management</a></li>
							  <li><a href="CorporateTrainings.php" class="positionsCorpTrain">Digital Marketing</a></li>
							  <li class="last"><a href="ITConsulting.php" class="positionsInfrMgmt">IT Consulting</a></li>
							  <li class="text">ANJS Tech helps you to align & strategize the IT infrastructure tailored to match your business goals. <a href="InfrastructureManagement.php" class="hrf">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></li>
							  <li class="text">ANJS Tech provides exp. server engineers to help monitor, maintain & support your cloud & virtual servers. <a href="CorporateTrainings.php" class="hrf">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></li>
							  <li class="text last">ANJS Tech has wide range of IT consultants that are available to push your organization in right direction. <a href="ITConsulting.php" class="hrf">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></li>							  
							</ul>
							<div class="clear"></div>
						  </div>
					</td>
				</tr>
			</table>
		
				</td>
	</tr>		
	<tr><td colspan="3" height="25px"></td></tr>	
</table>


<!--<div class="footernew">
	<table class="tablewidth" cellpadding="0" cellspacing="0" align="center">
		<tr>
			<td colspan="3">--><div class="footernew">
	<table class="tablewidth" cellpadding="0" cellspacing="0" align="center">
		<tr>
			<td colspan="3">
				<!--<div>
					<div style="display:inline">
						<div class="footertextnav"><strong>Company</strong><br />
							<p style="height:10px"></p>							
							<a class="footerhrefnew" href="CorporateOverview.html">Corporate Overview</a><br />
							<a class="footerhrefnew" href="AboutUs.html">Why ANJS Tech Inc</a><br />
							<a class="footerhrefnew" href="NewsEvents.html">News &amp; Events</a><br />
							<a class="footerhrefnew" href="EngagementModels.html">Engagement Models</a><br />
							<a class="footerhrefnew" href="AlliancesPartners.html">Alliances &amp; Partners</a>
						</div>
						<div class="footertextnav">
							<strong>Services</strong><br />
							<p style="height:10px"></p>
							<a class="footerhrefnew" href="StaffAugmentation.html">Staffing</a><br />	
							<a class="footerhrefnew" href="SoftwareDevelopment.html">Software Development</a><br />
							<a class="footerhrefnew" href="InfrastructureManagement.html">Infrastructure Management</a><br />
							<a class="footerhrefnew" href="SecurityServices.html">Security Services Portfolio</a><br />
							<a class="footerhrefnew" href="Mobile.html">Mobile</a><br />
							<a class="footerhrefnew" href="EngineeringDesignServices.html">Engineering Design Services</a><br />
							<a class="footerhrefnew" href="ITConsulting.html">IT Consulting</a><br />
							<a class="footerhrefnew" href="DigitalMarketing.html">Digital Marketing</a><br />
							<a class="footerhrefnew" href="CloudComputing.html">Virtualization / Cloud Computing</a><br />
							<a class="footerhrefnew" href="CorporateTrainings.html">Trainings</a>
						</div>
						<!--<div class="footertextnav">
							<strong>Technologies</strong><br />
							<p style="height:10px"></p>
							<a class="footerhrefnew" href="Mobile.php">Mobile</a><br />
							<a class="footerhrefnew" href="OpenSource.php">Open Source</a><br />
							<a class="footerhrefnew" href="Microsoft.php">Microsoft Technology</a>							
						</div>
						<div class="footertextnav">
							<strong>Clients</strong><br />
							<p style="height:10px"></p>
							<a class="footerhrefnew" href="Clients.html">Clients</a>			
						</div>
						<div class="footertextnav">
							<strong>Careers</strong><br />
							<p style="height:10px"></p>
							<a class="footerhrefnew" href="JobOpportunities.html">Job Opportunities</a><br />
							<a class="footerhrefnew" href="WorkCulture.html">Work Culture</a><br />
							<a class="footerhrefnew" href="ApplyOnline.html">Apply online</a><br />			
							<a class="footerhrefnew" href="ReferralPrograms.html">Referral Programs</a><br />
							<a class="footerhrefnew" href="WhatANJS Techoffers.html">What ANJS Tech offers</a>
						</div>
						<div class="footertextnavr">
							<strong>Contact Us</strong><br />
							<p style="height:10px"></p>
							<a class="footerhrefnew" href="ContactUs.html">Contact Us</a>
						</div>
					</div>
					<div class="hline"></div>
					<div style="font-family:Arial; font-size:15px; color:#FFFFFF; font-weight:bold;" class="footertextr"><i>Offices Locations:</i></div>
					<div style="float:right" class="footerlink">
							<div class="footer footertext"><a href="TermsofUse.html" class="footerhref">Terms of Use</a></div><div class="footertext separator">|</div><div class="footer footertext"><a href="PrivacyPolicy.html" class="footerhref">Privacy Policy</a></div><div class="footertext separator">|</div><div class="footer footertext"><a href="Sitemap.html" class="footerhref">Sitemap</a></div>
						</div>
					</div>-->
					<!--<div style="height:5px; clear:both"></div>
					<div style="float:left; clear:both" class="location">
						<div class="footer footertextr"><b>USA:</b></div><div class="footer footertextr"><a href="contactus-2.html" class="footerhref">New Jersey</a></div><div class="footertextr separator">|</div><div class="footer footertextr"><a href="contactus-2.html" class="footerhref">Texas</a></div><div class="footertextr separator">|</div><div class="footer footertextr"><a href="contactus-2.html" class="footerhref">Pennsylvania</a></div><div class="footertextr separator">|</div><div class="footer footertextr"><a href="contactus-2.html" class="footerhref">Virginia</a></div><div class="footertextr"> &nbsp;</div>
						<div class="footertext locationind">
							<div class="footer footertextr"><b>India:</b></div><div class="footer footertextr"><a href="contactus-2.html" class="footerhref">Vadodara</a></div><div class="footertextr separator">|</div><div class="footer footertextr"><a href="contactus-2.html" class="footerhref">Hyderabad</a></div>
						</div>
					</div>-->
					<div style="text-align:center;padding-top:10px;" class="footer copyright">2016 @ ANJS Tech. All Rights Reserved</div>
				</div>
			</td>
		</tr>
	</table>	
</div>
<!-- begin olark code -->

<script type="text/javascript">

            //jQuery.noConflict();
            //jQuery(window).load(function() {		   
			$(window).on("load", function() {
			//$(document).ready(function(){
				setTimeout(function(){
				jQuery('#slider').nivoSlider({        
                    effect:'fade',
                    slices:15,
                    animSpeed:0,
                    pauseTime:3000,
                    startSlide:0,
                    directionNav:true,
                    directionNavHide:false,
                    controlNav:false,
                    controlNavThumbs:false,
                    controlNavThumbsFromRel:true, 
                    keyboardNav:false,
                    pauseOnHover:true,
                    manualAdvance:true,
                    captionOpacity:1.0,
                    beforeChange: function(){},
                    afterChange: function(){},
                    slideshowEnd: function(){}
                }); 
                });
            });
	
//jQuery.noConflict();
jQuery(function($){ $("ul.sf-menu").superfish({hoverClass:'sfHover', pathClass:'active', pathLevels:0, delay:800, animation:{height:'show'}, speed:'def', autoArrows:0, dropShadows:1}) });
jQuery.event.special.hover.delay = 100;
jQuery.event.special.hover.speed = 100;
  </script>

</div>

</body>


</html>
